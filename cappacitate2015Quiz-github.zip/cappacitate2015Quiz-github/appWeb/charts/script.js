// Code goes here

angular.module('a', ['ionic', 'googlechart', 'firebase'])
    .controller('b', function($scope,$http, $timeout, $firebaseObject, $ionicLoading) {

        var ref = new Firebase("https://cappacitate2015quiz.firebaseio.com/");

        $scope.sampleData = {
            "type": "PieChart",
            "cssStyle": "height:200px; width:300px;",
            "data": {
                "cols": [
                    {
                        "id": "responses",
                        "label": "Respuestas",
                        "type": "string"
                    },
                    {
                        "id": "responsesBar",
                        "label": "Respuestas",
                        "type": "number"
                    }
                ],
                "rows": [
                    {
                        "c": [
                            {
                                "v": "A"
                            },
                            {
                                "v": 0
                            }
                        ]
                    },
                    {
                        "c": [
                            {
                                "v": "B"
                            },
                            {
                                "v": 0
                            }
                        ]
                    },
                    {
                        "c": [
                            {
                                "v": "C"
                            },
                            {
                                "v": 0
                            }
                        ]
                    },
                    {
                        "c": [
                            {
                                "v": "D"
                            },
                            {
                                "v": 0
                            }
                        ]
                    },
                    {
                        "c": [
                            {
                                "v": "E"
                            },
                            {
                                "v": 0
                            }
                        ]
                    }
                ]
            },
            "options": {
                "title": "Resultados por respuesta",
                "isStacked": "true",
                "fill": 20,
                "displayExactValues": true,
                "vAxis": {
                    "title": "Respuestas",
                    "gridlines": {
                        "count": 6
                    }
                },
                "hAxis": {
                    "title": "Date"
                }
            },
            "formatters": {}
        };

        $scope.newUser = '';

        // download the data into a local object
        $scope.data = $firebaseObject(ref);

        $scope.responsesData = {
            'A': 0,
            'B': 0,
            'C': 0,
            'D': 0,
            'E': 0,
        };
        

        $timeout(function() {

            $scope.$watchCollection('data.responses', function(newNames, oldNames) {
                console.log('newNames:', newNames);
                updateChart();
            });

            $scope.$watchCollection('data.users', function(newNames, oldNames) {
                console.log('users:', newNames);

                var keys = Object.keys(newNames);
                console.log(keys);

                $scope.newUser = ' | Nuevo usuario: ' + newNames[keys[keys.length-1]];

                console.log($scope.newUser);

                
                /*var msg = $ionicLoading.show({
                    template: $scope.newUser
                });*/

                $timeout(function () {
                    $scope.newUser = '';
                }, 1000);
                
            });

        }, 1000);

        var updateChart = function () {
            console.log('update chart!');

            angular.forEach($scope.data.responses, function (response) {
                console.log(response);

                switch(response) {
                    case 'A':
                        $scope.responsesData.A++;
                    break;

                    case 'B':
                        $scope.responsesData.B++;
                    break;

                    case 'C':
                        $scope.responsesData.C++;
                    break;

                    case 'D':
                        $scope.responsesData.D++;
                    break;

                    case 'E':
                        $scope.responsesData.E++;
                    break;

                    default:
                        console.log('no idea.');
                    break;
                }

            });

            console.log('$scope.responsesData:', $scope.responsesData);

            // se actualizan los datos de la grafica
            $scope.sampleData = {
                "type": "PieChart",
                "cssStyle": "height:200px; width:300px;",
                "data": {
                    "cols": [
                        {
                            "id": "responses",
                            "label": "Respuestas",
                            "type": "string"
                        },
                        {
                            "id": "responsesBar",
                            "label": "Respuestas",
                            "type": "number"
                        }
                    ],
                    "rows": [
                        {
                            "c": [
                                {
                                    "v": "A"
                                },
                                {
                                    "v": $scope.responsesData.A
                                }
                            ]
                        },
                        {
                            "c": [
                                {
                                    "v": "B"
                                },
                                {
                                    "v": $scope.responsesData.B
                                }
                            ]
                        },
                        {
                            "c": [
                                {
                                    "v": "C"
                                },
                                {
                                    "v": $scope.responsesData.C
                                }
                            ]
                        },
                        {
                            "c": [
                                {
                                    "v": "D"
                                },
                                {
                                    "v": $scope.responsesData.D
                                }
                            ]
                        },
                        {
                            "c": [
                                {
                                    "v": "E"
                                },
                                {
                                    "v": $scope.responsesData.E
                                }
                            ]
                        }
                    ]
                },
                "options": {
                    "title": "Resultados por respuesta",
                    "isStacked": "true",
                    "fill": 20,
                    "displayExactValues": true,
                    "vAxis": {
                        "title": "Respuestas",
                        "gridlines": {
                            "count": 6
                        }
                    },
                    "hAxis": {
                        "title": "Date"
                    }
                },
                "formatters": {}
            };
        }

        

    });