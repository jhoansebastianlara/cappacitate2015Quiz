ionic-chart-example
===================

This Sample contains the usage of common java script charting libraries with ionic.


JavaScript Charting Libraries included are:

1. Google Charts
2. D3 JS
3. Highcharts